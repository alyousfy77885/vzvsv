    <div id="container">
        <div id="demo_box_2">
            <span class="pop_ctrl"><i class="fa fa-bars" style="font-size:30px"></i></span>
            <ul id="demo_ul_2">
                <li class="demo_li"><a href="#"><div><i class="fa fa-home"></i></div><div>Home</div></a></li>
                <li class="demo_li"><div><i class="fa fa-cloud"></i></div><div>Cloud</div></li>
                <li class="demo_li"><div><i class="fa fa-cog"></i></div><div>settings</div></li>
                <li class="demo_li"><div><i class="fa fa-envelope"></i></div><div>E-mail</div></li>
                <li class="demo_li"><div><i class="fa fa-clock-o"></i></div><div>Clock</div></li>
                <li class="demo_li"><div><i class="fa fa-folder"></i></div><div>Files</div></li>
                <li class="demo_li">
<div>

   <div class="header-ctn">
										<!-- Cart -->
							

								<!-- Cart -->
								<div class="dropdown">
				
									<a class="dropdown-toggl" data-toggle="dropdown" aria-expanded="true">
											
        <i class="fa fa-heart-o" style="font-size:20px;margin-top:1px"></i>

            <div class="badge qty">

									
</div>
									</a>
									<div class="cart-dropdown"  >
										<div class="cart-list" id="cart_product">
										
											
										</div>
										
										<div class="cart-btns">
												<a href="cart.php" style="width:100%;"><i class="fa fa-edit"></i>  تعديل الطلب</a>
											
										</div>
									</div>
					
									</div>
									</div>
</div>

								<!-- /Cart -->
								<!-- /Menu Toogle -->
						

<div>Favourites</div></li>
                <li class="demo_li"><div><i class="fa fa-mobile"></i></div><div>Mobile</div></li>
           </ul>        </div>
        </div>