

        

        <div id="newsletter" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
					
						<div class="newsletter">
							<p>يرجى الاشتراك <strong>للاعلانات</strong></p>

							<form id="offer_forrm" onsubmit="return false" style="width:100%;display:block" class="form-inline">
 <div class="form-group">
             
								<input class="form-control" type="email" id="email" name="email" placeholder="البريد الالكتروني">
							<input type="submit" class="btn btn-primary " name="submit" value="اشتراك">
                                
	</div>
							</form>
							<div class="" id="offer_msg">
                                <!--Alert from signup form-->
                            </div>
							<ul class="newsletter-follow">
								<li>
									<a href="#"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a href="#"><i class="fa fa-instagram"></i></a>
								</li>
								
							</ul>
						</div>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>